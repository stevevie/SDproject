package proj;
public class Servidor1_RMI {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
